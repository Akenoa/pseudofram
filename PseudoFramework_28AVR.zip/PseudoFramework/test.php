<?php 
$tableauTest = [ 

        'id'=>'1',
        'qtepdt'=>'2',
        'nompdt'=>'sac de pomme de terre',
];
$tableauTest['id']='888';
$var=implode(",",$tableauTest);
$foo=implode(",",array_keys($tableauTest));
var_dump($var);
echo "<br />";
var_dump($foo);







/*$tableauTest=[
        "PHP",
        "Javascript",
        //"Csharp",
        //"Java",
        //"Python",
]; 
$tableauTestDel=array_slice($tableauTest,0,1);
$tableauTestDel2=array_slice($tableauTest,1);




//$NombreElement = count($tableauTest); 
print_r($tableauTestDel);
echo "<br />";
print_r($tableauTestDel2);
//echo $NombreElement;*/